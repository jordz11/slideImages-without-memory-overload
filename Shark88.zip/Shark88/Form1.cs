﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.IO;
using System.Collections;
using Microsoft.Win32;

namespace Shark88
{
    public partial class Form1 : Form
    {
        private System.Drawing.Bitmap MyBitmap;
        private Size MyBitmapSize = new Size(640, 480);
        private PointF MyPoint = new Point(320, 240);
        private float fScale = 1.00F;
        public Graphics gx;

        private int nSelectedFile = -1;
        private string szRequestedFile;
        private ArrayList FileArray;
        private ArrayList FileTypes;
        public string szCurrentDirectory;

        public Form1()
        {
            InitializeComponent();
            string path = "D:\\Programming\\Shark88\\Shark88\\bin\\Debug\\imagelist1";  //Debug path 1
            Directory.SetCurrentDirectory(path);//Directory.GetParent(path).FullName.ToString() );
            szRequestedFile = path;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // initialize the image types array
                FileTypes = new ArrayList();
                FileTypes.Add("*.JPG");
                FileTypes.Add("*.JPEG");
                FileTypes.Add("*.GIF");
                FileTypes.Add("*.BMP");
                FileTypes.Add("*.PNG");
                FileTypes.Add("*.TIF");
                FileTypes.Add("*.TIFF");

                ProcessDirectory();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private string GetFilePath()
        {
            if (nSelectedFile > FileArray.Count)
                nSelectedFile = 0;
            return FileArray[nSelectedFile].ToString();
        }

        private void SetPicture()
        {
            try
            {
                this.Text = GetFilePath() + " - QuickView";

                MyBitmap = new Bitmap(GetFilePath());
                //SetSize();

                this.Invalidate();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
#if FALSE
        private void Form1_Paint(object sender, PaintEventArgs e)
        {

            if (MyBitmap != null)
            {
                //Graphics g = e.Graphics;
                //MyPoint.X = (this.Width - MyBitmap.Width * (fScale)) / 2;
                //MyPoint.Y = (((this.Height) - MyBitmap.Height * (fScale)) / 2);
                //g.DrawImage(MyBitmap,0,0);
            }

            if (MyBitmap != null)
            {
                using (Graphics g = e.Graphics)
                {
                    //g.DrawImage(MyBitmap, 0, 0);
                    //g.Dispose();
                }
                    
            }
            
        }
#endif
            private void timer1_Tick(object sender, EventArgs e)
        {
            nSelectedFile++;
            if (nSelectedFile >= FileArray.Count)
                nSelectedFile = 0;
            //SetPicture();
            this.Text = FileArray[nSelectedFile].ToString() + " - QuickView";

            using (var temp = Image.FromFile(FileArray[nSelectedFile].ToString()))
            {
                if (temp != null)
                {
                    using (Graphics g = this.CreateGraphics())//Graphics.FromImage(temp))
                    {
                        g.DrawImage(temp, new Rectangle(0, 0, temp.Width, temp.Height));
                        //g.DrawImage(temp, 0, 0, 500, 500);
                        //g.DrawImage(temp, 0, 0);
                        //this.Invalidate();
                        //MyBitmap = new Bitmap(temp);
                        Refresh();
                    }

                    //MyPoint.X = (this.Width - MyBitmap.Width * (fScale)) / 2;
                    //MyPoint.Y = (((this.Height) - MyBitmap.Height * (fScale)) / 2);
                    //g.DrawImage(MyBitmap,0,0);
                }
            }
        }

        private void ProcessDirectory()
        {
            string[] szFiles;
            FileArray = new ArrayList();

            // find image files
            foreach (string szType in FileTypes)
            {
                szFiles = Directory.GetFiles(Directory.GetCurrentDirectory(), szType);
                if (szFiles.Length > 0)
                    FileArray.AddRange(szFiles);
            }
            if (FileArray.Count > 0)
            {
                if (szRequestedFile.ToString() != "")
                {
                    nSelectedFile = FileArray.IndexOf(szRequestedFile);
                }
            }
            else
            {
                nSelectedFile = -1;
            }
        }
    }
}
