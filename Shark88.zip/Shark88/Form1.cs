﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.IO;
using System.Collections;
using Microsoft.Win32;

namespace Shark88
{
    public partial class Form1 : Form
    {
        private System.Drawing.Bitmap MyBitmap;
        private Size MyBitmapSize = new Size(640, 480);
        private PointF MyPoint = new Point(320, 240);
        private float fScale = 1.00F;
        public Graphics gx;

        private int nSelectedFile = -1;
        private string szRequestedFile;
        private ArrayList FileArray;
        private ArrayList FileTypes;
        public string szCurrentDirectory;

        public string[] pthfiles = new string[100];
        public int init = 0;
        string[] files0;
        string[] files1;
        string[] files2;
        string[] files3;
        string[] files4;
        string[] files5;
        string[] files6;
        string[] files7;
        string[] files8;
        string[] files9;
        string[] files10;

        public Form1()
        {
            string[] xpath;
            string[] sep = { "file:\\", "" };

            InitializeComponent();

            BackColor = Color.Lime;
            TransparencyKey = Color.Lime;
            FormBorderStyle = FormBorderStyle.None;

            string path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
            var systemPath = System.Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
            xpath = path.Split(sep, StringSplitOptions.None);
            //Directory.SetCurrentDirectory(path);//Directory.GetParent(path).FullName.ToString() );
            //szRequestedFile = path;
            path = xpath[1];

            try
            {
                // initialize the image types array
                FileTypes = new ArrayList();
                FileTypes.Add("*.JPG");
                FileTypes.Add("*.JPEG");
                FileTypes.Add("*.GIF");
                FileTypes.Add("*.BMP");
                FileTypes.Add("*.PNG");
                FileTypes.Add("*.TIF");
                FileTypes.Add("*.TIFF");

                ProcessDirectory();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            if (File.Exists(path + @"\\data.dat"))
            {
                ReadWidgetData(path, ref pthfiles);
            }
            else
            {
                FileStream fs = new FileStream(path + @"\\data.dat", FileMode.CreateNew);
                StreamWriter w = new StreamWriter(fs);
                w.WriteLine(path + "\\00. KPI(BS1-1)");
                w.WriteLine(path + "\\01. KPI(BS1-2)");
                w.WriteLine(path + "\\02. Jenkins Schedule");
                w.WriteLine(path + "\\03. Jira Kanban");
                w.WriteLine(path + "\\04. User Guide");
                w.WriteLine(path + "\\05. Task Assignment");
                w.WriteLine(path + "\\06. O.T Management(BS1-1)");
                w.WriteLine(path + "\\07. O.T Management(BS1-2)");
                w.WriteLine(path + "\\08. Event and Announcement");
                w.WriteLine(path + "\\09. Today's Nihongo");
                w.WriteLine(path + "\\10. Latest News");
                w.Close();
                fs.Close();
                ReadWidgetData(path, ref pthfiles);
            }
            GetImageList(ref pthfiles, 0, ref files0);
        }

        /*-------------------------------------------------------------------------------------------*/
        /* Get Image List                                                                            */ 
        /*-------------------------------------------------------------------------------------------*/
        private void GetImageList(ref string[] xPth,  int idx, ref string[] fls)
        {
            string[] szFiles;
            FileArray = new ArrayList();

            // find image files
            foreach (string szType in FileTypes)
            {
                szFiles = Directory.GetFiles(xPth[idx], szType);
                if (szFiles.Length > 0)
                    FileArray.AddRange(szFiles);
            }
            if (FileArray.Count > 0)
            {
                fls = new string[FileArray.Count];
                for (int i = 0; i < FileArray.Count; i++)
                {
                    fls[i] = FileArray[i].ToString();
                }
            }
        }

        /*-------------------------------------------------------------------------------------------*/
        /* Get Directory                                                                             */
        /*-------------------------------------------------------------------------------------------*/
        private void ProcessDirectory()
        {
            string[] szFiles;
            FileArray = new ArrayList();

            // find image files
            foreach (string szType in FileTypes)
            {
                szFiles = Directory.GetFiles(Directory.GetCurrentDirectory(), szType);
                if (szFiles.Length > 0)
                    FileArray.AddRange(szFiles);
            }
            if (FileArray.Count > 0)
            {
                if (szRequestedFile.ToString() != "")
                {
                    nSelectedFile = FileArray.IndexOf(szRequestedFile);
                }
            }
            else
            {
                nSelectedFile = -1;
            }
        }

        /*-------------------------------------------------------------------------------------------*/
        /* Read                                                                                      */
        /*-------------------------------------------------------------------------------------------*/
        void ReadWidgetData(string pth, ref string[] fldr)
        {
            string txt;
            string[] temp = null;
            try
            {
                using(StreamReader r = File.OpenText(pth + @"/data.dat"))
                {
                    txt = r.ReadToEnd();
                    r.Close();
                }
                temp = Regex.Split(txt, "\r\n");
                for(int i=0; i < temp.Length; i++)
                {
                    fldr[i] = temp[i];
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("An error occur during data reading: " + pth + ";" + "/n" + ex.ToString(), this.Text);
            }
        }

        /*-------------------------------------------------------------------------------------------*/
        /* Set Picture in a pBox                                                                     */
        /*-------------------------------------------------------------------------------------------*/
        void SetPictureInAPictureBox(ref string[] fls, ref PictureBox p, ref TabControl tc, Boolean sts)
        {
            if(fls.Length > 0)
            {
                if(init < fls.Length)
                {
                    using(var tempImg = Image.FromFile(fls[init]))
                    {
                        if(tempImg != null)
                        {
                            using(Graphics g = p.CreateGraphics())
                            {
                                g.DrawImage(tempImg,0,0, p.Width, p.Height);
                            }
                        }
                    }
                    init++;
                }
                else
                {
                    init = 0;
                }
            }
        }

        /*-------------------------------------------------------------------------------------------*/
        /* Form Load                                                                                 */
        /*-------------------------------------------------------------------------------------------*/
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        /*-------------------------------------------------------------------------------------------*/
        /* Timer                                                                                     */
        /*-------------------------------------------------------------------------------------------*/
        private void timer1_Tick(object sender, EventArgs e)
        {
            if(tabControl1.SelectedTab == tabControl1.TabPages["tabPage1"])
            {
                SetPictureInAPictureBox(ref files0, ref pBox1, ref tabControl1, false);
            }
        }

        private string GetFilePath()
        {
            if (nSelectedFile > FileArray.Count)
                nSelectedFile = 0;
            return FileArray[nSelectedFile].ToString();
        }

        private void SetPicture()
        {
            try
            {
                //this.Text = GetFilePath() + " - QuickView";

                MyBitmap = new Bitmap(GetFilePath());
                //SetSize();

                this.Invalidate();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
