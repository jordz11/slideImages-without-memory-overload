using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using Microsoft.Win32;

namespace QuickView
{
	/// <summary>
	/// The Options form where the current user can modify settings
	/// </summary>
	public class Options : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variables.
		/// </summary>
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.CheckBox checkBoxFullScreen;
		private System.Windows.Forms.CheckBox checkBoxSizeToFit;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.CheckBox checkBoxSlideShow;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ColorDialog colorDialog;
		private System.Windows.Forms.Label label2;
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Panel panelColor;
		private System.Windows.Forms.Button buttonColor;
		private System.Windows.Forms.NumericUpDown numericUpDownTime;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.HelpProvider helpProvider;
		private System.Windows.Forms.Button buttonCancel;


		/// <summary>
		/// =============
		/// REGISTRY VARs
		/// =============
		/// szRegPath			- the path of the key in the registry where the current user's setting values will be stored
		/// nSizeToFit			- whether to resize the image to fit window
		/// nFullScreen			- whether to show images in full screen as default [nonexistant for now]
		/// nFullScreenColorR	- the R channel value of the background when fullscreen
		/// nFullScreenColorG	- the G channel value of the background when fullscreen
		/// nFullScreenColorB	- the B channel value of the background when fullscreen
		/// nDefaultSlideShow	- whether to show images as slide show as default
		/// nSlideTimer			- the value of the interval between slides during slide show
		/// </summary>
		public const string  szRegPath = "SOFTWARE\\QuickView\\1.0\\";
		private int nSizeToFit			= 1;
		private int nFullScreen			= 0;
		private int nFullScreenColorR	= 0;
		private int nFullScreenColorG	= 0;
		private int nFullScreenColorB	= 0;
		private int nDefaultSlideShow	= 0;
		private int nSlideTimer			= 500;


		public Options()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonColor = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panelColor = new System.Windows.Forms.Panel();
            this.checkBoxFullScreen = new System.Windows.Forms.CheckBox();
            this.checkBoxSizeToFit = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBoxSlideShow = new System.Windows.Forms.CheckBox();
            this.numericUpDownTime = new System.Windows.Forms.NumericUpDown();
            this.buttonOK = new System.Windows.Forms.Button();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.helpProvider = new System.Windows.Forms.HelpProvider();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTime)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonColor);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.panelColor);
            this.groupBox1.Controls.Add(this.checkBoxFullScreen);
            this.groupBox1.Controls.Add(this.checkBoxSizeToFit);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(26, 32);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(464, 256);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Display";
            // 
            // buttonColor
            // 
            this.buttonColor.Enabled = false;
            this.buttonColor.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonColor.Location = new System.Drawing.Point(368, 176);
            this.buttonColor.Name = "buttonColor";
            this.buttonColor.Size = new System.Drawing.Size(48, 46);
            this.buttonColor.TabIndex = 6;
            this.buttonColor.Text = "...";
            this.buttonColor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonColor.Click += new System.EventHandler(this.buttonColor_Click);
            // 
            // label2
            // 
            this.label2.Enabled = false;
            this.label2.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 176);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(256, 64);
            this.label2.TabIndex = 5;
            this.label2.Text = "Full screen background colour:";
            // 
            // panelColor
            // 
            this.panelColor.BackColor = System.Drawing.SystemColors.Control;
            this.panelColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelColor.Enabled = false;
            this.panelColor.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelColor.Location = new System.Drawing.Point(288, 176);
            this.panelColor.Name = "panelColor";
            this.panelColor.Size = new System.Drawing.Size(64, 48);
            this.panelColor.TabIndex = 4;
            // 
            // checkBoxFullScreen
            // 
            this.checkBoxFullScreen.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxFullScreen.Location = new System.Drawing.Point(32, 112);
            this.checkBoxFullScreen.Name = "checkBoxFullScreen";
            this.checkBoxFullScreen.Size = new System.Drawing.Size(416, 48);
            this.checkBoxFullScreen.TabIndex = 3;
            this.checkBoxFullScreen.Text = "Always display images full screen";
            // 
            // checkBoxSizeToFit
            // 
            this.checkBoxSizeToFit.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxSizeToFit.Location = new System.Drawing.Point(32, 48);
            this.checkBoxSizeToFit.Name = "checkBoxSizeToFit";
            this.checkBoxSizeToFit.Size = new System.Drawing.Size(336, 48);
            this.checkBoxSizeToFit.TabIndex = 2;
            this.checkBoxSizeToFit.Text = "Size images to fit window";
            this.checkBoxSizeToFit.CheckedChanged += new System.EventHandler(this.checkBoxSizeToFit_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.checkBoxSlideShow);
            this.groupBox2.Controls.Add(this.numericUpDownTime);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(26, 336);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(464, 240);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Slide Show";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(192, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(176, 32);
            this.label3.TabIndex = 3;
            this.label3.Text = "milli seconds";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 144);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(288, 32);
            this.label1.TabIndex = 2;
            this.label1.Text = "Interval between slides:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // checkBoxSlideShow
            // 
            this.checkBoxSlideShow.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxSlideShow.Location = new System.Drawing.Point(32, 64);
            this.checkBoxSlideShow.Name = "checkBoxSlideShow";
            this.checkBoxSlideShow.Size = new System.Drawing.Size(400, 48);
            this.checkBoxSlideShow.TabIndex = 1;
            this.checkBoxSlideShow.Text = "Default slide show";
            // 
            // numericUpDownTime
            // 
            this.numericUpDownTime.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownTime.Increment = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.numericUpDownTime.Location = new System.Drawing.Point(64, 176);
            this.numericUpDownTime.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownTime.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.numericUpDownTime.Name = "numericUpDownTime";
            this.numericUpDownTime.ReadOnly = true;
            this.numericUpDownTime.Size = new System.Drawing.Size(128, 33);
            this.numericUpDownTime.TabIndex = 0;
            this.numericUpDownTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDownTime.ThousandsSeparator = true;
            this.numericUpDownTime.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            // 
            // buttonOK
            // 
            this.buttonOK.Location = new System.Drawing.Point(96, 608);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(150, 46);
            this.buttonOK.TabIndex = 5;
            this.buttonOK.Text = "OK";
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(272, 608);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(150, 46);
            this.buttonCancel.TabIndex = 6;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // helpProvider
            // 
            this.helpProvider.HelpNamespace = "C:\\Documents and Settings\\Administrator.SERVER\\My Documents\\Visual Studio Project" +
    "s\\QuickView\\QuickView\\help.chm";
            // 
            // Options
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(12, 26);
            this.ClientSize = new System.Drawing.Size(258, 335);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.helpProvider.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Options";
            this.helpProvider.SetShowHelp(this, true);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Options";
            this.Load += new System.EventHandler(this.Options_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTime)).EndInit();
            this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// =================
		/// OPTIONS FORM LOAD
		/// =================
		/// When this form loads, obtain the current user's registry settings
		/// If there are no key's at present, create new ones using default values
		/// Once done, initialize the variables and the form controls
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Options_Load(object sender, System.EventArgs e)
		{
			try
			{
				RegistryKey MyReg = Registry.CurrentUser.OpenSubKey(szRegPath);
				if( MyReg==null )
				{
					MyReg = Registry.CurrentUser.CreateSubKey( szRegPath );

					MyReg.SetValue( "nSizeToFit",			1 );
					MyReg.SetValue( "nFullScreen",			0 );
					MyReg.SetValue( "nFullScreenColorR",	0 );
					MyReg.SetValue( "nFullScreenColorG",	0 );
					MyReg.SetValue( "nFullScreenColorB",	0 );
					MyReg.SetValue( "nDefaultSlideShow",	0 );
					MyReg.SetValue( "nSlideTimer",			500 );

					MyReg.Close();
				}
				else
				{
					nSizeToFit			= Convert.ToInt16(MyReg.GetValue( "nSizeToFit",			1 ));
					nFullScreen			= Convert.ToInt16(MyReg.GetValue( "nFullScreen",		0 ));
					nFullScreenColorR	= Convert.ToInt16(MyReg.GetValue( "nFullScreenColorR",	0 ));
					nFullScreenColorG	= Convert.ToInt16(MyReg.GetValue( "nFullScreenColorG",	0 ));
					nFullScreenColorB	= Convert.ToInt16(MyReg.GetValue( "nFullScreenColorB",	0 ));
					nDefaultSlideShow	= Convert.ToInt16(MyReg.GetValue( "nDefaultSlideShow",	0 ));
					nSlideTimer			= Convert.ToInt16(MyReg.GetValue( "nSlideTimer",		500 ));
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.ToString(), "Cannot access registry", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}

			if( nSizeToFit==0 )
				checkBoxSizeToFit.Checked=false;
			else
				checkBoxSizeToFit.Checked=true;

			if( nDefaultSlideShow==0 )
				checkBoxSlideShow.Checked=false;
			else
				checkBoxSlideShow.Checked=true;

			numericUpDownTime.Value = nSlideTimer;

			// these lines would be uncommented once i get full screen functionality right
//			Color MyColor;
//			MyColor.ToKnownColor
//			MyColor.R = nFullScreenColorR;
//			MyColor.G = nFullScreenColorG;
//			MyColor.B = nFullScreenColorB;
//
//			panelColor.BackColor = MyColor;
//			panelColor.Invalidate();

		}

		/// <summary>
		/// ==
		/// OK
		/// ==
		/// If the user clicks OK, retrieve all the values from the controls
		/// and then write those to the registry 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			// Retreive Values from the Dialog
			if( checkBoxSizeToFit.Checked )
				nSizeToFit = 1;
			else
				nSizeToFit = 0;

			if( checkBoxFullScreen.Checked )
				nFullScreen = 1;
			else
				nFullScreen = 0;

			nFullScreenColorR = panelColor.ForeColor.R;
			nFullScreenColorG = panelColor.ForeColor.G;
			nFullScreenColorB = panelColor.ForeColor.B;

			if( checkBoxSlideShow.Checked )
				nDefaultSlideShow = 1;
			else
				nDefaultSlideShow = 0;

			nSlideTimer = Convert.ToInt16(numericUpDownTime.Value);
			// EOR

			try
			{
				RegistryKey MyReg = Registry.CurrentUser.OpenSubKey(szRegPath, true);
				if( MyReg==null )
				{
					MyReg = Registry.CurrentUser.CreateSubKey( szRegPath );

					MyReg.SetValue( "nSizeToFit",			1 );
					MyReg.SetValue( "nFullScreen",			0 );
					MyReg.SetValue( "nFullScreenColorR",	0 );
					MyReg.SetValue( "nFullScreenColorG",	0 );
					MyReg.SetValue( "nFullScreenColorB",	0 );
					MyReg.SetValue( "nDefaultSlideShow",	0 );
					MyReg.SetValue( "nSlideTimer",			5 );
				}
				else
				{
					MyReg.SetValue( "nSizeToFit",			nSizeToFit );
					MyReg.SetValue( "nFullScreen",			nFullScreen );
					MyReg.SetValue( "nFullScreenColorR",	nFullScreenColorR );
					MyReg.SetValue( "nFullScreenColorG",	nFullScreenColorG );
					MyReg.SetValue( "nFullScreenColorB",	nFullScreenColorB );
					MyReg.SetValue( "nDefaultSlideShow",	nDefaultSlideShow );
					MyReg.SetValue( "nSlideTimer",			nSlideTimer );
				}
				MyReg.Close();
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.ToString(), "Cannot access registry", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			this.Close();
		}

		private void buttonColor_Click(object sender, System.EventArgs e)
		{
			colorDialog.Color = panelColor.ForeColor;
			if( colorDialog.ShowDialog()==DialogResult.OK )
			{
				panelColor.ForeColor	= colorDialog.Color;
				nFullScreenColorR		= colorDialog.Color.R;
				nFullScreenColorG		= colorDialog.Color.G;
				nFullScreenColorB		= colorDialog.Color.B;
//
//				panelColor.ForeColor = new Color( nFullScreenColorR, nFullScreenColorG, nFullScreenColorB );
//				panelColor.Invalidate();
			}
		}

		/// <summary>
		/// ======
		/// CANCEL
		/// ======
		/// If the user clicks on cancel, then just close the form
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

        private void checkBoxSizeToFit_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
