///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ================================
// QuickView v1.0
// Copyright (C) 2003, Rakesh Rajan
// Built on 24/02/2003
// ================================
//
// Developed by,
// Rakesh Rajan
// e-mail: mailto:rakesh_rajan@rediffmail.com
// home-page: http://www.rakeshrajan.20m.com
//
// Windows Installer and updates available at: http://www.geocities.com/rakeshrajanhere/QuickView.msi
//
//
// DESCRIPTION
// ===========
// QuickView is a free and open source image viewer application, entirely built upon the .NET platform, using Visual C#. It
// supports at present JPG, BMP, GIF, PNG, TIF image file formats.
//
//
// INSTALLATION
// ============
// Download the latest windows installer from the link provided above, and setup.
//
//
// REQUIREMENTS
// ============
// Any Windows operating system.
// .NET Framework installed.
// 
//
// DECLARATION
// ===========
// THIS IS TO CERTIFY THAT THIS SOFTWARE 'QUICKVIEW', WAS DEVELOPED COMPLETELY BY THE AUTHOR STATED AND THAT ANY SIMILARITY TO
// OTHER SOFTWARES IS PURELY COINCIDENTAL. THE AUTHOR STATES THAT THIS SOFTWARE IS FREEWARE AND MAY BE FREELY DISTRIBUTED THROUGH
// ANY MEANS, WITHOUT ANY CHARGE. THE AUTHOR ALSO STATES THAT THIS SOFTWARE IS OPEN SOURCE, AND MAY BE MODIFIED FREELY, PROVIDED, 
// THE MODIFIER CLEARLY STATES CREDIT TO THE AUTHOR, AND WHOSE MODIFIED VERSION AS WELL AS SOURCE CODE MAY NOT CHARGED 
// FOR. THE AUTHOR IS NOT RESPONSIBLE FOR ANY DAMAGES INCURRED TO THE USER'S COMPUTER BY USAGE OF THIS SOFTWARE.
// 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Microsoft.Win32;

namespace QuickView
{
	/// <summary>
	/// Main Form:
	/// This is the main form of this app. This is where the images will be displayed.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		#region WinForm Designer generated vars
		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem menuItemFile;
		private System.Windows.Forms.MenuItem menuItemExitCmd;
		private System.Windows.Forms.MenuItem menuItemView;
		private System.Windows.Forms.MenuItem menuItemOptionsCmd;
		private System.Windows.Forms.MenuItem menuItemHelp;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.ImageList imageList;
		private System.Windows.Forms.ToolBar toolBar;
		private System.Windows.Forms.OpenFileDialog openFileDialog;
		private System.Windows.Forms.MenuItem menuItemOpen;
		private System.Timers.Timer timer;
		private System.Windows.Forms.MenuItem menuItemSlideShow;
		private System.Windows.Forms.ToolBarButton toolBarButtonOpen;
		private System.Windows.Forms.ToolBarButton toolBarButtonSlideShow;
		private System.Windows.Forms.ToolBarButton toolBarButtonOptions;
		private System.Windows.Forms.StatusBarPanel statusBarPanelMouse;
		private System.Windows.Forms.ToolBarButton toolBarButtonZoomIn;
		private System.Windows.Forms.ToolBarButton toolBarButtonZoomOut;
		private System.Windows.Forms.ToolBarButton toolBarButtonNoZoom;
		private System.Windows.Forms.ToolBarButton toolBarButtonNextImage;
		private System.Windows.Forms.ToolBarButton toolBarButtonPreviousImage;
		private System.Windows.Forms.ImageList imageListImageTypes;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItemNextImage;
		private System.Windows.Forms.MenuItem menuItemPreviousImage;
		private System.Windows.Forms.MenuItem menuItemZoomIn;
		private System.Windows.Forms.MenuItem menuItemNoZoom;
		private System.Windows.Forms.MenuItem menuItemZoomOut;
		private System.Windows.Forms.MenuItem menuItemAboutCmd;
		private System.Windows.Forms.MenuItem menuItemSizeToFit;
		private System.Windows.Forms.ToolBarButton toolBarButtonAbout;
		private System.Windows.Forms.HelpProvider helpProvider;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.ComponentModel.IContainer components;
		#endregion

		#region My Var Declarations
		/// <summary>
		/// ============
		/// GENERAL VARs
		/// ============
		/// nSelectedFile			- the index number of the currently selected file. If -1, then no file is selected.
		/// szRequestedFile			- the absolute file path of the requested file name when the app is called (from explorer)
		/// FileArray				- the arraylist storing all the image files within the current folder
		/// FileType				- the arraylist storing all the supported image types
		/// szCurrentDirectory		- the string storing the values of the path of the folder explorer called this app from
		/// </summary>
		private int			nSelectedFile = -1;
		private string		szRequestedFile;
		private ArrayList	FileArray;
		private ArrayList	FileTypes;
		public string		szCurrentDirectory;
		
		/// <summary>
		/// ==========
		/// IMAGE VARs
		/// ==========
		/// MyBitmap		- the obj in which the current image is stores
		/// MyBitmapSize	- the obj in which MyBitmap's size is stored
		/// MyFormSize		- the obj to store a temp size structure for resizing the form
		/// MyPoint			- the obj to store the centralized position where the image is to be drawn
		/// fScale			- the amount up to which the image is to scaled
		/// </summary>
		private System.Drawing.Bitmap	MyBitmap;
		private Size					MyBitmapSize = new Size(640, 480);
		private Size					MyFormSize   = new Size(0, 0);
		private PointF					MyPoint = new Point(320, 240);
		private float					fScale = 1.00F;
		
		
		/// <summary>
		/// ===============
		/// STATUS BAR OBJs
		/// ===============
		/// statusBar				- the status bar object
		/// statusBarPanelStatus	- displays the current status of the app viz., 'Ready' or 'Working'
		/// statusBarPanelImageSize - displays the image size '(width x height)'
		/// statusBarPanelFiles		- displays the number of image files within the current folder
		/// statusBarPanelZoom      - displays the amount to which the currently displayed image is zoomed to
		/// </summary>
		private System.Windows.Forms.StatusBar		statusBar;
		private System.Windows.Forms.StatusBarPanel statusBarPanelStatus;
		private System.Windows.Forms.StatusBarPanel statusBarPanelImageType;
		private System.Windows.Forms.StatusBarPanel statusBarPanelImageSize;
		private System.Windows.Forms.StatusBarPanel statusBarPanelFiles;
		private System.Windows.Forms.StatusBarPanel statusBarPanelZoom;

		/// <summary>
		/// =============
		/// REGISTRY VARs
		/// =============
		/// szRegPath			- the path of the key in the registry where the current user's setting values will be stored
		/// nSizeToFit			- whether to resize the image to fit window
		/// nFullScreen			- whether to show images in full screen as default [nonexistant for now]
		/// nFullScreenColorR	- the R channel value of the background when fullscreen
		/// nFullScreenColorG	- the G channel value of the background when fullscreen
		/// nFullScreenColorB	- the B channel value of the background when fullscreen
		/// nDefaultSlideShow	- whether to show images as slide show as default
		/// nSlideTimer			- the value of the interval between slides during slide show
		/// </summary>
		public const string		szRegPath			= "SOFTWARE\\QuickView\\1.0\\";
		private int				nSizeToFit			= 1;
		private int				nFullScreen			= 0;
		private int				nFullScreenColorR	= 0;
		private int				nFullScreenColorG	= 0;
		private int				nFullScreenColorB	= 0;
		private int				nDefaultSlideShow	= 0;
		private int				nSlideTimer			= 500;

		#endregion

		#region App Main Entry
		/// <summary>
		/// ============
		/// MAIN FUNTION
		/// ============
		/// - This funtion is called when the app first starts.
		/// - string[] args is used to obtain the command-line arguments
		/// - If there are no arguments, use MainForm()
		/// - or else use MainForm( string ) to pass the argument to the main form
		/// </summary>
		[STAThread]
		static void Main( string[] args ) 
		{
			if( args.Length<1 )
				Application.Run(new MainForm());
			else
				Application.Run(new MainForm( args[0] ));
		}

		/// <summary>
		/// =====================
		/// MAINFORM CONSTRUCTORS
		/// =====================
		/// Defines two constructors for Main Form():
		/// 
		/// MainForm()
		/// Called when this app is executed without requesting any file (no cmd-line arguments)in the commandline.
		/// 
		/// MainForm(string szPath)
		/// Called when this app is executed, requesting an image file (cmd-line args exist) to be displayed. 
		/// This is the case usually when the app is called from explorer
		/// szPath defines the current path as in the command line
		/// </summary>
		public MainForm()
		{
			InitializeComponent();
			Text = "QuickView";
			ClientSize = MyBitmapSize;
		}
		public MainForm(string szPath)
		{
			InitializeComponent();
			Text = "QuickView";
			ClientSize = MyBitmapSize;
			
			//
			// Set the current dir to that of the requested file so that 
			// i could display the file, process the dir etc.
			// Do this by extracting the parent dir from szPath
			//
			Directory.SetCurrentDirectory( Directory.GetParent(szPath).FullName.ToString() );
			szRequestedFile = szPath;
		}
		#endregion

		#region OtherStuff
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.menuItemFile = new System.Windows.Forms.MenuItem();
			this.menuItemOpen = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItemNextImage = new System.Windows.Forms.MenuItem();
			this.menuItemPreviousImage = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItemExitCmd = new System.Windows.Forms.MenuItem();
			this.menuItemView = new System.Windows.Forms.MenuItem();
			this.menuItemSlideShow = new System.Windows.Forms.MenuItem();
			this.menuItemSizeToFit = new System.Windows.Forms.MenuItem();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItemZoomIn = new System.Windows.Forms.MenuItem();
			this.menuItemNoZoom = new System.Windows.Forms.MenuItem();
			this.menuItemZoomOut = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuItemOptionsCmd = new System.Windows.Forms.MenuItem();
			this.menuItemHelp = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItemAboutCmd = new System.Windows.Forms.MenuItem();
			this.statusBar = new System.Windows.Forms.StatusBar();
			this.statusBarPanelStatus = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanelMouse = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanelFiles = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanelImageType = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanelImageSize = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanelZoom = new System.Windows.Forms.StatusBarPanel();
			this.toolBar = new System.Windows.Forms.ToolBar();
			this.toolBarButtonOpen = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonPreviousImage = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonNextImage = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonSlideShow = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonZoomIn = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonNoZoom = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonZoomOut = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonOptions = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonAbout = new System.Windows.Forms.ToolBarButton();
			this.imageList = new System.Windows.Forms.ImageList(this.components);
			this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.timer = new System.Timers.Timer();
			this.imageListImageTypes = new System.Windows.Forms.ImageList(this.components);
			this.helpProvider = new System.Windows.Forms.HelpProvider();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanelStatus)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanelMouse)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanelFiles)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanelImageType)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanelImageSize)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanelZoom)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.timer)).BeginInit();
			this.SuspendLayout();
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuItemFile,
																					 this.menuItemView,
																					 this.menuItemHelp});
			// 
			// menuItemFile
			// 
			this.menuItemFile.Index = 0;
			this.menuItemFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItemOpen,
																						 this.menuItem7,
																						 this.menuItemNextImage,
																						 this.menuItemPreviousImage,
																						 this.menuItem5,
																						 this.menuItemExitCmd});
			this.menuItemFile.Text = "&File";
			// 
			// menuItemOpen
			// 
			this.menuItemOpen.Index = 0;
			this.menuItemOpen.Shortcut = System.Windows.Forms.Shortcut.CtrlO;
			this.menuItemOpen.Text = "&Open...";
			this.menuItemOpen.Click += new System.EventHandler(this.menuItemOpen_Click);
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 1;
			this.menuItem7.Text = "-";
			// 
			// menuItemNextImage
			// 
			this.menuItemNextImage.Index = 2;
			this.menuItemNextImage.Text = "Next image";
			this.menuItemNextImage.Click += new System.EventHandler(this.menuItemNextImage_Click);
			// 
			// menuItemPreviousImage
			// 
			this.menuItemPreviousImage.Index = 3;
			this.menuItemPreviousImage.Text = "Previous image";
			this.menuItemPreviousImage.Click += new System.EventHandler(this.menuItemPreviousImage_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 4;
			this.menuItem5.Text = "-";
			// 
			// menuItemExitCmd
			// 
			this.menuItemExitCmd.Index = 5;
			this.menuItemExitCmd.Text = "&Exit";
			this.menuItemExitCmd.Click += new System.EventHandler(this.menuItemExitCmd_Click);
			// 
			// menuItemView
			// 
			this.menuItemView.Index = 1;
			this.menuItemView.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItemSlideShow,
																						 this.menuItemSizeToFit,
																						 this.menuItem1,
																						 this.menuItemZoomIn,
																						 this.menuItemNoZoom,
																						 this.menuItemZoomOut,
																						 this.menuItem10,
																						 this.menuItemOptionsCmd});
			this.menuItemView.Text = "&View";
			// 
			// menuItemSlideShow
			// 
			this.menuItemSlideShow.Index = 0;
			this.menuItemSlideShow.Text = "S&lide Show";
			this.menuItemSlideShow.Click += new System.EventHandler(this.menuItemSlideShow_Click);
			// 
			// menuItemSizeToFit
			// 
			this.menuItemSizeToFit.Index = 1;
			this.menuItemSizeToFit.Text = "Size to fit";
			this.menuItemSizeToFit.Click += new System.EventHandler(this.menuItemSizeToFit_Click);
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 2;
			this.menuItem1.Text = "-";
			// 
			// menuItemZoomIn
			// 
			this.menuItemZoomIn.Index = 3;
			this.menuItemZoomIn.Text = "Zoom in 10%";
			this.menuItemZoomIn.Click += new System.EventHandler(this.menuItemZoomIn_Click);
			// 
			// menuItemNoZoom
			// 
			this.menuItemNoZoom.Index = 4;
			this.menuItemNoZoom.Text = "Actual size";
			this.menuItemNoZoom.Click += new System.EventHandler(this.menuItemNoZoom_Click);
			// 
			// menuItemZoomOut
			// 
			this.menuItemZoomOut.Index = 5;
			this.menuItemZoomOut.Text = "Zoom out 10%";
			this.menuItemZoomOut.Click += new System.EventHandler(this.menuItemZoomOut_Click);
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 6;
			this.menuItem10.Text = "-";
			// 
			// menuItemOptionsCmd
			// 
			this.menuItemOptionsCmd.Index = 7;
			this.menuItemOptionsCmd.Text = "&Options...";
			this.menuItemOptionsCmd.Click += new System.EventHandler(this.menuItemOptionsCmd_Click);
			// 
			// menuItemHelp
			// 
			this.menuItemHelp.Index = 2;
			this.menuItemHelp.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItem2,
																						 this.menuItemAboutCmd});
			this.menuItemHelp.Text = "&Help";
			// 
			// menuItem2
			// 
			this.menuItem2.Enabled = false;
			this.menuItem2.Index = 0;
			this.menuItem2.Text = "Press F1 for Help";
			// 
			// menuItemAboutCmd
			// 
			this.menuItemAboutCmd.Index = 1;
			this.menuItemAboutCmd.Text = "&About...";
			this.menuItemAboutCmd.Click += new System.EventHandler(this.menuItemAboutCmd_Click);
			// 
			// statusBar
			// 
			this.statusBar.Location = new System.Drawing.Point(0, 413);
			this.statusBar.Name = "statusBar";
			this.statusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						 this.statusBarPanelStatus,
																						 this.statusBarPanelMouse,
																						 this.statusBarPanelFiles,
																						 this.statusBarPanelImageType,
																						 this.statusBarPanelImageSize,
																						 this.statusBarPanelZoom});
			this.statusBar.ShowPanels = true;
			this.statusBar.Size = new System.Drawing.Size(632, 20);
			this.statusBar.TabIndex = 0;
			this.statusBar.Text = "Ready";
			// 
			// statusBarPanelStatus
			// 
			this.statusBarPanelStatus.Text = "Ready";
			this.statusBarPanelStatus.Width = 10;
			// 
			// statusBarPanelFiles
			// 
			this.statusBarPanelFiles.Text = "-no file(s)-";
			// 
			// statusBarPanelImageType
			// 
			this.statusBarPanelImageType.Text = "-none-";
			this.statusBarPanelImageType.Width = 200;
			// 
			// toolBar
			// 
			this.toolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this.toolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																					   this.toolBarButtonOpen,
																					   this.toolBarButtonPreviousImage,
																					   this.toolBarButtonNextImage,
																					   this.toolBarButtonSlideShow,
																					   this.toolBarButtonZoomIn,
																					   this.toolBarButtonNoZoom,
																					   this.toolBarButtonZoomOut,
																					   this.toolBarButtonOptions,
																					   this.toolBarButtonAbout});
			this.toolBar.Cursor = System.Windows.Forms.Cursors.Default;
			this.toolBar.Divider = false;
			this.toolBar.DropDownArrows = true;
			this.toolBar.ImageList = this.imageList;
			this.toolBar.Name = "toolBar";
			this.toolBar.ShowToolTips = true;
			this.toolBar.Size = new System.Drawing.Size(632, 39);
			this.toolBar.TabIndex = 1;
			this.toolBar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar_ButtonClick);
			// 
			// toolBarButtonOpen
			// 
			this.toolBarButtonOpen.ImageIndex = 2;
			this.toolBarButtonOpen.ToolTipText = "Open image";
			// 
			// toolBarButtonPreviousImage
			// 
			this.toolBarButtonPreviousImage.ImageIndex = 3;
			this.toolBarButtonPreviousImage.ToolTipText = "Show previous image";
			// 
			// toolBarButtonNextImage
			// 
			this.toolBarButtonNextImage.ImageIndex = 4;
			this.toolBarButtonNextImage.ToolTipText = "Show next image";
			// 
			// toolBarButtonSlideShow
			// 
			this.toolBarButtonSlideShow.ImageIndex = 5;
			this.toolBarButtonSlideShow.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.toolBarButtonSlideShow.ToolTipText = "Start slide show";
			// 
			// toolBarButtonZoomIn
			// 
			this.toolBarButtonZoomIn.ImageIndex = 6;
			this.toolBarButtonZoomIn.ToolTipText = "Zoom in image 10%";
			// 
			// toolBarButtonNoZoom
			// 
			this.toolBarButtonNoZoom.ImageIndex = 7;
			this.toolBarButtonNoZoom.ToolTipText = "Show actual size";
			// 
			// toolBarButtonZoomOut
			// 
			this.toolBarButtonZoomOut.ImageIndex = 8;
			this.toolBarButtonZoomOut.ToolTipText = "Zoom out image 10%";
			// 
			// toolBarButtonOptions
			// 
			this.toolBarButtonOptions.ImageIndex = 9;
			this.toolBarButtonOptions.ToolTipText = "Set options";
			// 
			// toolBarButtonAbout
			// 
			this.toolBarButtonAbout.ImageIndex = 1;
			this.toolBarButtonAbout.ToolTipText = "View credits";
			// 
			// imageList
			// 
			this.imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.imageList.ImageSize = new System.Drawing.Size(32, 32);
			this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
			this.imageList.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// openFileDialog
			// 
			this.openFileDialog.Filter = "\"All Image Files (JPEG, GIF, BMP, etc.)|*.jpg;*.jpeg;*.gif;*.bmp;*.tif;*.tiff;*.p" +
				"ng|JPEG files (*.jpg;*.jpeg)|*.jpg;*.jpeg|GIF Files (*.gif)|*.gif|BMP Files (*.b" +
				"mp)|*.bmp|TIFF Files (*.tif;*.tiff)|*.tif;*.tiff|PNG Files (*.png)|*.png\"";
			this.openFileDialog.Title = "Open Image";
			// 
			// timer
			// 
			this.timer.Enabled = true;
			this.timer.Interval = 500;
			this.timer.SynchronizingObject = this;
			this.timer.Elapsed += new System.Timers.ElapsedEventHandler(this.timer_Elapsed);
			// 
			// imageListImageTypes
			// 
			this.imageListImageTypes.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.imageListImageTypes.ImageSize = new System.Drawing.Size(32, 32);
			this.imageListImageTypes.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListImageTypes.ImageStream")));
			this.imageListImageTypes.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// helpProvider
			// 
			this.helpProvider.HelpNamespace = "C:\\Documents and Settings\\Administrator.SERVER\\My Documents\\Visual Studio Project" +
				"s\\QuickView\\QuickView\\help.chm";
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 13);
			this.AutoScroll = true;
			this.ClientSize = new System.Drawing.Size(632, 433);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.toolBar,
																		  this.statusBar});
			this.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.helpProvider.SetHelpKeyword(this, "");
			this.helpProvider.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.helpProvider.SetHelpString(this, "");
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.mainMenu;
			this.MinimumSize = new System.Drawing.Size(100, 100);
			this.Name = "MainForm";
			this.helpProvider.SetShowHelp(this, true);
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "QuickView";
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
			this.SizeChanged += new System.EventHandler(this.MainForm_SizeChanged);
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MainForm_KeyPress);
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyUp);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.MainForm_Paint);
			this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseMove);
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanelStatus)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanelMouse)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanelFiles)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanelImageType)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanelImageSize)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanelZoom)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.timer)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion
        
		#endregion

		#region MainForm Load
		/// <summary>
		/// =============
		/// MAINFORM LOAD
		/// =============
		/// - Initialize variables
		/// - Setup the form controls
		/// - Process the current folder
		/// - If an image file is requested, show it
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void MainForm_Load(object sender, System.EventArgs e)
		{
			// get this user's settings of this app
			GetRegistrySettings();
			
			// make sure that the timer is off
			timer.Stop();
			
			try
			{
				// initialize the image types array
				FileTypes = new ArrayList();
				FileTypes.Add("*.JPG");
				FileTypes.Add("*.JPEG");
				FileTypes.Add("*.GIF");
				FileTypes.Add("*.BMP");
				FileTypes.Add("*.PNG");
				FileTypes.Add("*.TIF");
				FileTypes.Add("*.TIFF");

				// set all the controls present in the form to the user's settings
				SetControlsToRegistrySettings();

				// process current folder
				ProcessDirectory();

				// if a file is requested, make the form display it
				if( nSelectedFile!=-1 )
				{
					// set the image in the form. 
					// if 'view as slide show' setting is default, show slide show
					// by setting the timer interval and starting the timer
					SetPicture();
					if( nDefaultSlideShow==1 )
					{
						timer.Interval = nSlideTimer;
						timer.Start();
					}
				}

			}
			catch(Exception ex)
			{
				statusBarPanelStatus.Text = "ERROR: " + ex.ToString();
			}
		}
		#endregion

		#region MainForm Paint Handler
		/// <summary>
		/// =================
		/// THE PAINT HANDLER
		/// =================
		/// - Set the status bar text to 'Working...'
		/// - Initialize a new Graphics object if MyBitmap is not null
		/// - If the setting for 'Size to fit' is zero, display the image normally. If it doesn't fit, set AutoScroll to true.
		///	- Else, calculate how much fScale should be so as to fit the image within the window
		///	- Draw the image at the center of the form or at the autoscroll position
		///	- Set the values of the status bar panels
		///	- Set the status bar text to 'Ready'
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void MainForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			statusBarPanelStatus.Text = "Working...";
			if( MyBitmap != null )
			{
				try
				{
					Graphics g = e.Graphics;

					if( nSizeToFit==0 )
					{
						// image fits in form
						if( MyBitmap.Width*(fScale)<=this.Width && MyBitmap.Height*(fScale)<=this.Height-statusBar.Height-toolBar.Height )
						{
							this.AutoScroll=false;
							MyPoint.X = (this.Width - MyBitmap.Width*(fScale))/2;
							MyPoint.Y = (((this.Height-statusBar.Height-toolBar.Height) - MyBitmap.Height*(fScale))/2) + toolBar.Height - statusBar.Height;
							g.DrawImage( MyBitmap, new RectangleF(MyPoint.X, MyPoint.Y, MyBitmap.Width*(fScale), MyBitmap.Height*(fScale)) );
						}
						// height doesn't fit
						else if( MyBitmap.Width*(fScale)<=this.Width && MyBitmap.Height*(fScale)>this.Height-statusBar.Height-toolBar.Height ) 
						{
							this.AutoScroll=true;
							MyPoint.X = (this.Width-MyBitmap.Width*(fScale))/2;
							MyPoint.Y = this.AutoScrollPosition.Y;
							g.DrawImage( MyBitmap, new RectangleF(MyPoint.X, MyPoint.Y, MyBitmap.Width*(fScale), MyBitmap.Height*(fScale)) );
						}
						// width doesn't fit
						else if( MyBitmap.Height*(fScale)<=this.Height-statusBar.Height-toolBar.Height && MyBitmap.Width*(fScale)>this.Width ) 
						{
							this.AutoScroll=true;
							MyPoint.X = this.AutoScrollPosition.X;
							MyPoint.Y = (((this.Height-statusBar.Height-toolBar.Height)-MyBitmap.Height*(fScale))/2) + toolBar.Height - statusBar.Height;
							g.DrawImage( MyBitmap, new RectangleF(MyPoint.X, MyPoint.Y, MyBitmap.Width*(fScale), MyBitmap.Height*(fScale)) );
						}
						// both width and height doesn't fit
						else
						{
							this.AutoScroll=true;
							g.DrawImage( MyBitmap, this.AutoScrollPosition.X, this.AutoScrollPosition.Y, MyBitmap.Width*(fScale), MyBitmap.Height*(fScale) );
						}
					}
					else
					{
						this.AutoScroll=false;
						
						// diff in width is greater; so take that scale
						if( this.Width/MyBitmap.Width < (this.Height-statusBar.Height-toolBar.Height)/MyBitmap.Height )
						{
							fScale = this.Width/MyBitmap.Width;
						}
						else
						{
							fScale = (this.Height-statusBar.Height-toolBar.Height)/MyBitmap.Height;
						}
						
						MyPoint.X = (this.Width - MyBitmap.Width*(fScale))/2;
						MyPoint.Y = (((this.Height-statusBar.Height-toolBar.Height) - MyBitmap.Height*(fScale))/2) + toolBar.Height - statusBar.Height;
						g.DrawImage( MyBitmap, new RectangleF(MyPoint.X, MyPoint.Y, MyBitmap.Width*(fScale), MyBitmap.Height*(fScale)) );
					}
					
					statusBarPanelZoom.Text = Convert.ToString((fScale*100)) + "%";
					statusBarPanelImageType.Text = MyBitmap.PixelFormat.ToString();
					statusBarPanelImageSize.Text = MyBitmap.Width.ToString() + "x" + MyBitmap.Height.ToString();
				}
				catch(Exception ex)
				{
					statusBarPanelStatus.Text = "ERROR: " + ex.ToString();
				}
			}
			statusBarPanelStatus.Text = "Ready";
		}
		#endregion

		#region UserDefined Funtions
		/// <summary>
		/// =====================
		/// USER DEFINED FUNTIONS
		/// =====================
		/// 
		/// GetRegistrySettings()
		/// Gets the current user's registry settings from the registry and initializes the registry vars
		/// 
		/// SetControlsToRegistrySettings()
		/// Resets the form controls so as to set it to the current user's settings
		/// 
		/// SetSize()
		/// Resizes the form according to the current Image's size
		/// 
		/// Process Directory()
		/// Finds out all the images within the current folder and initializes FileArray
		/// 
		/// GetFilePath()
		/// Get's the currently selected file's path from FileArray
		/// 
		/// SetPicture()
		/// Sets variables to the selected file's attributes and invokes the paint handler
		/// 
		/// </summary>
		public void GetRegistrySettings()
		{
			try
			{
				RegistryKey MyReg = Registry.CurrentUser.OpenSubKey(szRegPath);
				if( MyReg==null )
				{
					MyReg = Registry.CurrentUser.CreateSubKey( szRegPath );

					MyReg.SetValue( "nSizeToFit",			1 );
					MyReg.SetValue( "nFullScreen",			0 );
					MyReg.SetValue( "nFullScreenColorR",	0 );
					MyReg.SetValue( "nFullScreenColorG",	0 );
					MyReg.SetValue( "nFullScreenColorB",	0 );
					MyReg.SetValue( "nDefaultSlideShow",	0 );
					MyReg.SetValue( "nSlideTimer",			500 );
				}
				else
				{
					nSizeToFit			= Convert.ToInt16(MyReg.GetValue( "nSizeToFit",			1 ));
					nFullScreen			= Convert.ToInt16(MyReg.GetValue( "nFullScreen",		0 ));
					nFullScreenColorR	= Convert.ToInt16(MyReg.GetValue( "nFullScreenColorR",	0 ));
					nFullScreenColorG	= Convert.ToInt16(MyReg.GetValue( "nFullScreenColorG",	0 ));
					nFullScreenColorB	= Convert.ToInt16(MyReg.GetValue( "nFullScreenColorB",	0 ));
					nDefaultSlideShow	= Convert.ToInt16(MyReg.GetValue( "nDefaultSlideShow",	0 ));
					nSlideTimer			= Convert.ToInt16(MyReg.GetValue( "nSlideTimer",		500 ));
				}
				MyReg.Close();
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.ToString(), "Cannot access registry", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void SetControlsToRegistrySettings()
		{
			if( nSizeToFit==1 )
				menuItemSizeToFit.Checked=true;
			else
				menuItemSizeToFit.Checked=false;

			if( nDefaultSlideShow==1 )
				menuItemSlideShow.Checked = toolBarButtonSlideShow.Pushed = true;
			else
				menuItemSlideShow.Checked = toolBarButtonSlideShow.Pushed = false;
			timer.Interval = nSlideTimer;
		}

		private void SetSize()
		{
			if( MyBitmap.Width>=this.Width || MyBitmap.Height>this.Height )
			{
				if( MyBitmap.Width>640 || MyBitmap.Height>480 )
				{
					this.Width = 640;
					this.Height = 480;
					this.AutoScrollMinSize = MyBitmap.Size;
				}
				else
				{
					this.AutoScrollMinSize = MyBitmap.Size;
				}
			}
		}

		private void ProcessDirectory()
		{
			string[] szFiles;
			FileArray = new ArrayList();

			// find image files
			foreach( string szType in FileTypes )
			{
				szFiles = Directory.GetFiles( Directory.GetCurrentDirectory(), szType);
				if( szFiles.Length>0 )
					FileArray.AddRange( szFiles );
			}
			if( FileArray.Count>0 )
			{
				if( szRequestedFile.ToString()!="" )
				{
					nSelectedFile = FileArray.IndexOf(szRequestedFile);
				}
			}
			else
			{
				nSelectedFile = -1;
			}
		}

		private string GetFilePath()
		{
			if( nSelectedFile>FileArray.Count ) nSelectedFile = 0;
			return FileArray[nSelectedFile].ToString();
		}

		private void SetPicture()
		{
			try
			{
				this.Text = GetFilePath() + " - QuickView";
				statusBarPanelFiles.Text = (nSelectedFile+1).ToString() + "/" + FileArray.Count.ToString();

				MyBitmap = new Bitmap( GetFilePath() );
				SetSize();
			
				this.Invalidate();
			}
			catch(Exception ex)
			{
				statusBarPanelStatus.Text = "ERROR: " + ex.ToString();
			}
		}

		#endregion

		#region Event Handlers
		/// <summary>
		/// ==============
		/// EVENT HANDLERS
		/// ==============
		/// 
		/// MainForm_MouseMove()
		/// Called when the mouse moves.
		/// Set the status bar panel text to current mouse position.
		/// 
		/// MainForm_SizeChanged()
		/// Called when the form is resized.
		/// Resize the status bar panel sizes and then invoke the main form paint handler
		/// 
		/// timer_Elapsed()
		/// Called when the timer interval has elapsed.
		/// Set the selected image to the next one 
		/// Set the scaling to normal
		/// Invoke the paint handler
		/// 
		/// toolBar_ButtonClick()
		/// Called when the user clicks a button on the tool bar
		/// Determine which button was clicked
		/// Call the appropriate DoAction handler
		/// 
		/// MainForm_KeyUp()
		/// Called when the user releases a key
		/// Determine which key was released
		/// Call the appropriate DoAction handler
		/// 
		/// ...
		/// ...
		/// Menu Handlers for each of the menu items
		/// ...
		/// ...
		/// Calls the apprropriate DoAction handler
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void MainForm_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			Point tempPoint = this.PointToClient(MousePosition);
			statusBarPanelMouse.Text = "(" + tempPoint.X + ", " + tempPoint.Y + ")";
		}

		private void MainForm_SizeChanged(object sender, System.EventArgs e)
		{
			statusBarPanelStatus.Width		= Convert.ToInt16( 0.4 * this.Width );
			statusBarPanelFiles.Width		= Convert.ToInt16( 0.1 * this.Width );
			statusBarPanelMouse.Width		= Convert.ToInt16( 0.1 * this.Width );
			statusBarPanelImageType.Width	= Convert.ToInt16( 0.2 * this.Width );
			statusBarPanelImageSize.Width	= Convert.ToInt16( 0.1 * this.Width );
			statusBarPanelZoom.Width		= Convert.ToInt16( 0.1 * this.Width );

			this.Invalidate();
		}

		private void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
		{
			if( nSelectedFile!=-1 )
			{
				fScale = 1.00F;
				nSelectedFile++;
				if( nSelectedFile>=FileArray.Count )
					nSelectedFile = 0;
				SetPicture();
			}
		}

		private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			switch (toolBar.Buttons.IndexOf(e.Button))
			{
				case 0 : // open
					DoAction("OpenFile");
					break;

				case 1: // next image
					DoAction("NextImage");
					break;

				case 2: // prev image
					DoAction("PreviousImage");
					break;

				case 3: // slide show
					DoAction("SlideShow");
					break;

				case 4: // zoom in
					DoAction("ZoomIn");
					break;

				case 5: // no zoom
					DoAction("NoZoom");
					break;

				case 6: // zoom in
					DoAction("ZoomOut");
					break;

				case 7: // set options
					DoAction("SetOptions");
					break;

				case 8:
					DoAction("About");
					break;
			}
		
		}

		private void MainForm_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			switch( e.KeyCode.ToString() )
			{
				case "Escape":
					DoAction("Exit");
					break;
				case "F5":
					DoAction("Refresh");
					break;
				case "Space":
					DoAction("NextImage");
					break;
				case "Back":
					DoAction("PreviousImage");
					break;
				case "Home":
					DoAction("Home");
					break;
				case "End":
					DoAction("End");
					break;
				case "PageDown":
					DoAction("PageDown");
					break;
				case "PageUp":
					DoAction("PageUp");
					break;
				case "Add":
					DoAction("ZoomIn");
					break;
				case "Subtract":
					DoAction("ZoomOut");
					break;
			}
		}
		private void MainForm_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
		}
		private void MainForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
		}
		private void menuItemHelpAndAboutCmd_Click(object sender, System.EventArgs e)
		{
			DoAction("HelpAndAbout");
		}

		private void menuItemExitCmd_Click(object sender, System.EventArgs e)
		{
			DoAction("Exit");
		}

		private void menuItemSlideShow_Click(object sender, System.EventArgs e)
		{
			DoAction("SlideShow");
		}

		private void menuItemOptionsCmd_Click(object sender, System.EventArgs e)
		{
			DoAction("SetOptions");
		}

		private void menuItemOpen_Click(object sender, System.EventArgs e)
		{
			DoAction("OpenFile");
		}

		private void menuItemNoZoom_Click(object sender, System.EventArgs e)
		{
			DoAction("SizeToFit");
		}

		private void menuItemNextImage_Click(object sender, System.EventArgs e)
		{
			DoAction("NextImage");
		}

		private void menuItemPreviousImage_Click(object sender, System.EventArgs e)
		{
			DoAction("PreviousImage");
		}

		private void menuItemZoomIn_Click(object sender, System.EventArgs e)
		{
			DoAction("ZoomIn");
		}

		private void menuItemZoomOut_Click(object sender, System.EventArgs e)
		{
			DoAction("ZoomOut");
		}
		private void menuItemHelpCmd_Click(object sender, System.EventArgs e)
		{
			DoAction("Help");
		}

		private void menuItemAboutCmd_Click(object sender, System.EventArgs e)
		{
			DoAction("About");
		}

		private void menuItemSizeToFit_Click(object sender, System.EventArgs e)
		{
			DoAction("SizeToFit");
		}

		#endregion

		#region The DoAction Handler
		/// <summary>
		/// =================
		/// DO ACTION HANDLER
		/// =================
		/// This funtion incorporates all the possible actions that would be invoked within this app. This funtion was developed
		/// in order to reduce redundant code that would have to be coded for both the toolbar as well as the main menu. Plus
		/// this model reduces complexity.
		/// </summary>
		/// <param name="szAction">The name of the action to be executed</param>
		private void DoAction(string szAction)
		{
			switch(szAction)
			{
				case "Exit":
					// exit the app
					this.Close();
					Application.Exit();
					break;

				case "Refresh":
					// just invoke the paint handler
					this.Invalidate();
					break;

				case "OpenFile":
					// Show the openfiledialog
					// if user presses ok, set the current dir to that of the requested file
					// process that directory
					// set scale to normal
					// show the image
					if( openFileDialog.ShowDialog()==DialogResult.OK )
					{
						szRequestedFile = openFileDialog.FileName;
						Directory.SetCurrentDirectory( Directory.GetParent(szRequestedFile).FullName.ToString() );
						ProcessDirectory();
						fScale = 1.00F;
						if( nSelectedFile!=-1 )
							SetPicture();
					}
					break;

				case "SetOptions":
					// call the option's form
					// if user presses ok, reset the resigtry settings
					// and then set the controls to those settings
					Form frmOptions = new Options();
					if( frmOptions.ShowDialog()==DialogResult.OK )
					{
						GetRegistrySettings();
						SetControlsToRegistrySettings();
					}
					break;

				case "ZoomIn":
					// if the scale value is less than 50,000, then increase the value by 25%
					// and then call the paint handler
					if( fScale<50.00F ) 
						fScale+=0.25F;
					this.Invalidate();
					break;

				case "ZoomOut":
					// if the scale value is greater than 25, then decrease the value by 25%
					// and then call the paint handler
					if( fScale>0.25F )
						fScale-=0.25F;
					this.Invalidate();
					break;

				case "NoZoom":
					// reset the scale value to no zoom
					// and then call the paint handler
					fScale = 1.00F;
					this.Invalidate();
					break;

				case "Home":
					// set the selected file as the top most one in FileArray
					// and then call the paint handler
					nSelectedFile = 0;
					SetPicture();
					break;

				case "End":
					// set the selected file as the bottom one in FileArray
					// and then call the paint handler
					nSelectedFile = FileArray.Count-1;
					SetPicture();
					break;

				case "NextImage":
					// set the selected file as the next one
					// and then call the paint handler
					if( nSelectedFile!=-1 )
					{
						fScale = 1.00F;
						nSelectedFile++;
						if( nSelectedFile>=FileArray.Count )
							nSelectedFile = 0;
						SetPicture();
					}
					break;

				case "PreviousImage":
					// set the selected file as the previous one
					// and then call the paint handler
					if( nSelectedFile!=-1 )
					{
						fScale = 1.00F;
						nSelectedFile--;
						if( nSelectedFile<0 )
							nSelectedFile = FileArray.Count-1;
						SetPicture();
					}
					break;

				case "PageDown":
					// [not working]
					// set the selected file as the file 10 time below
					// and then call the paint handler
					nSelectedFile += 10;
					if( nSelectedFile>=FileArray.Count )
						nSelectedFile = 0;
					SetPicture();
					break;

				case "PageUp":
					// [not working]
					// set the selected file as the file 10 time above
					// and then call the paint handler
					nSelectedFile -= 10;
					if( nSelectedFile<0 )
						nSelectedFile = FileArray.Count-1;
					SetPicture();
					break;

				case "SlideShow":
					// reset the controls
					// set the timer if true or stop it if false
					if( menuItemSlideShow.Checked )
					{
						menuItemSlideShow.Checked = false;
						toolBarButtonSlideShow.Pushed = false;
						timer.Stop();
					}
					else
					{
						menuItemSlideShow.Checked = true;
						toolBarButtonSlideShow.Pushed = true;
						timer.Interval = nSlideTimer;
						timer.Start();
					}
					break;

				case "SizeToFit":
					// reset the controls
					// and then call the paint handler
					if( menuItemSizeToFit.Checked )
					{
						menuItemSizeToFit.Checked = false;
						nSizeToFit = 0;
					}
					else
					{
						menuItemSizeToFit.Checked = true;
						nSizeToFit = 1;
					}
					this.Invalidate();
					break;

				case "About":
					// show the about form
                    Form frmAbout = new About();
					frmAbout.ShowDialog();
					break;
			}
		}
		#endregion
	}
}
